import React, { useContext, useEffect, useState } from "react";
import { Redirect, useHistory } from "react-router-dom";
import { ToastContainer, toast } from "react-toast";
import "w3-css/w3.css";
import { AuthContext } from "../Auth";
import Store from "../../services/Store";

const Stores = ({ setComponentDisplay, updateOpenedStoreId }) => {
  const store = new Store();
  const [stores, putStoreList] = useState([]);

  useEffect(() => {
    var unsubscribe = store
      .listStoresForUser()
      .then((storesList) => {
        putStoreList(storesList.docs);
      })
      .catch((error) => {
        toast(error.message);
        return;
      });

    return () => {
      return unsubscribe;
    };
  }, []);

  const goToStoreHandler = (storeId) => {
    updateOpenedStoreId(storeId);
    setComponentDisplay("single");
  };

  return (
    <div>
      <div className="w3-row">
        {stores.map((store, index) => (
          <div key={index} className="w3-col m4 l3">
            <div
              className="w3-card-2"
              style={{ margin: "2%", background: "#cce6ff", padding: "2%" }}
            >
              <div className="w3-row">
                <b>{store.data().store_name}</b>
              </div>
              <div className="w3-row">
                Status:{" "}
                {store.data().approval_status
                  ? "Approved"
                  : "Not approve. Contact Support for Approval."}
              </div>
              <div className="w3-row">
                <button onClick={() => goToStoreHandler(store.id)}>View</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Stores;
