import React, { useContext, useEffect, useState } from "react";
import { Redirect, useHistory } from "react-router-dom";
import { ToastContainer, toast } from "react-toast";
import "w3-css/w3.css";
import { AuthContext } from "./Auth";
import firebaseConfig from "../config.js";
import Store from "../services/Store";
import StoresComponent from "../components/store/Stores";
import SingleStore from "../components/store/SingleStore";

const Dashboard = () => {
  let history = useHistory();
  const { currentUser } = useContext(AuthContext);
  const [componentDisplay, setComponentDisplay] = useState("all");
  const [storeId, updateOpenedStoreId] = useState("");

  const handleAddingStore = () => {
    history.push("/add_store");
  };

  if (!currentUser) {
    return <Redirect to="/login" />;
  }

  const myComponentDisplayed = () => {
    return componentDisplay == "all" ? (
      <StoresComponent
        updateOpenedStoreId={updateOpenedStoreId}
        setComponentDisplay={setComponentDisplay}
      />
    ) : (
      <SingleStore
        storeId={storeId}
        updateOpenedStoreId={updateOpenedStoreId}
        setComponentDisplay={setComponentDisplay}
      />
    );
  };

  return (
    <div>
      <ToastContainer />{" "}
      <button onClick={() => firebaseConfig.auth().signOut()}>Sign out</button>
      <h1>
        Welcome to <b>eSmall - Joburg</b>
      </h1>
      <button onClick={() => handleAddingStore()}>Add store</button>
      {myComponentDisplayed()}
    </div>
  );
};

export default Dashboard;
