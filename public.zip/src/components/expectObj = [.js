// expectObj = [
//   {
//     name: "",
//     avaliable_stock: "",
//     description: "",
//     price: "",
//     pictures: [
//       {
//         file: "file",
//         type: "",
//         name: "",
//       },
//     ],
//   },
// ];
